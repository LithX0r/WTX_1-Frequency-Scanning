### Description

Learning Center JKU, Altenbergerstr. 69 4040 Linz

### Coordinates

**Google Maps:** 48.3380630, 14.3212064
