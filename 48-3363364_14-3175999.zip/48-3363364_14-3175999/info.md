### Description
HS16 in JKU, Altenbergerstr. 69 4040 Linz

### Coordinates
**Google Maps:** 48.3363364, 14.3175999

