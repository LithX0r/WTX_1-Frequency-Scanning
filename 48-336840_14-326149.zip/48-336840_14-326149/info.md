### Description

Stone bench behind Keplerheim next to Altenbergerstr.

### Coordinates

**Google Maps:** 48.336840, 14.326149
